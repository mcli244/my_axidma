#include <linux/module.h>
#include <linux/platform_device.h>
#include <linux/dmaengine.h>
#include <linux/interrupt.h>
#include <linux/io.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/dma-mapping.h>
#include <linux/of.h>
#include <linux/of_address.h>
#include <linux/of_gpio.h>
#include <linux/of_irq.h>
#include <linux/ktime.h>
#include <linux/math64.h>

#define TEST_BUFFER_SIZE (1*1024)
#define TEST_DMA_ALIGNMENT 4
struct my_dma_test {
    struct dma_chan *tx_chan;       // DMA 通道
    struct dma_chan *rx_chan;       // DMA 通道
    uint8_t *src_buf;               // 源缓冲区
    uint8_t *dst_buf;               // 目标缓冲区
    dma_addr_t src_dma;             // 源DMA地址
    dma_addr_t dst_dma;             // 目标DMA地址
    struct platform_device *pdev; // 平台设备指针
    struct completion dma_rx_complete, dma_tx_complete;  // 用于等待 DMA 完成的完成信号量
    dma_cookie_t rx_cookie, tx_cookie;  // DMA cookie
    int irq_tx, irq_rx;             // DMA 中断号
    ktime_t	start, diff;
};

// 向后对齐
static void *addr_alignment(void *addr, unsigned int alignment)
{
    return (void *)(((uintptr_t)addr + alignment - 1) & ~(alignment - 1));
}

static void dma_rx_callback(void *param)
{
    struct my_dma_test *dma_test = (struct my_dma_test *)param;
    int i, ret, size, use_ms;
    double speed;

    pr_info("DMA transfer RX completed start data verification...\n");
    dma_test->diff = ktime_sub(ktime_get(), dma_test->start);

    for(i=0; i<TEST_BUFFER_SIZE; i++)
    {
        //pr_info("%02X ", dma_test->dst_buf[i]);
        if(dma_test->dst_buf[i] != dma_test->src_buf[i])
        {
            pr_err("Data verification failed! dst_buf[%03d]:%d --- src_buf[%03d]:%d\n", 
                i, dma_test->dst_buf[i], i, dma_test->src_buf[i]);
            complete(&dma_test->dma_rx_complete);
            return;
        }
    }

    pr_info("Data verification pass time:%d ns\n", ktime_to_ns(dma_test->diff));
    complete(&dma_test->dma_rx_complete);
}

static void dma_tx_callback(void *param)
{
    struct my_dma_test *data = (struct my_dma_test *)param;
    pr_info("DMA transfer TX completed\n");
    complete(&data->dma_tx_complete);
}

static int axi_dma_test_probe(struct platform_device *pdev)
{
    struct my_dma_test *dma_test;
    struct dma_async_tx_descriptor *tx_desc;
    struct dma_async_tx_descriptor *txd = NULL;
	struct dma_async_tx_descriptor *rxd = NULL;
    uint8_t *aligned_src_buf, *aligned_dst_buf;
    struct scatterlist tx_sg;
	struct scatterlist rx_sg;
    int ret, status;
    enum dma_ctrl_flags flags;
    unsigned long tx_tmo = msecs_to_jiffies(30000);
    unsigned long rx_tmo = msecs_to_jiffies(30000);
    int i;
    

    // 分配驱动结构体
    dma_test = devm_kzalloc(&pdev->dev, sizeof(struct my_dma_test), GFP_KERNEL);
    if (!dma_test)
        return -ENOMEM;

    dma_test->pdev = pdev;
    platform_set_drvdata(pdev, dma_test);

    /* 1. 申请DMA通道 
        axidmatest_0: axidmatest@0 {
                compatible ="xlnx,axi-dma-test-1.00.a";
                dmas = <&axi_dma_0 0
                        &axi_dma_0 1>;
                dma-names = "axidma0", "axidma1";
        };
    */
    dma_test->tx_chan = dma_request_chan(&pdev->dev, "axidma0");  // TX
    if (!dma_test->tx_chan) {
        pr_err("Failed to request DMA TX channel\n");
        ret = -ENODEV;
        goto err_devfree;
    }

    dma_test->rx_chan = dma_request_chan(&pdev->dev, "axidma1");  // RX
    if (!dma_test->rx_chan) {
        pr_err("Failed to request DMA RX channel\n");
        dma_release_channel(dma_test->tx_chan);
        ret = -ENODEV;
        goto err_devfree;
    }

    /* 2. 分配DMA内存
        这里分配了一个虚拟地址供CPU操作，另外映射了一个DMA地址供DMA操作(DMA需要使用物理地址)
        dma_test->src_buf： 虚拟地址
        dma_test->src_dma： 物理地址
    */
    // 小于4M的内存可以直接使用dma_alloc_coherent分配
    dma_test->src_buf = dma_alloc_coherent(&pdev->dev, TEST_BUFFER_SIZE, &dma_test->src_dma, GFP_KERNEL);
    dma_test->dst_buf = dma_alloc_coherent(&pdev->dev, TEST_BUFFER_SIZE, &dma_test->dst_dma, GFP_KERNEL);
    if(!dma_test->src_buf || !dma_test->dst_buf) {
        pr_err("Failed to allocate DMA memory\n");
        ret = -ENOMEM;
        goto err_devfree;
    }

    /* 3.  准备数据， 把数据源填充成特定值，用于后面校验对比。清空目的地缓存 */
    for(i=0; i<TEST_BUFFER_SIZE; i++)
    {
        dma_test->src_buf[i] = i;
        dma_test->dst_buf[i] = 0;
    }

    pr_info("#####src_buf: 0x%x, dma_test->src_dma: 0x%x\n", dma_test->src_buf, dma_test->src_dma);
    pr_info("#####dst_buf: 0x%x, dma_test->dst_dma: 0x%x\n", dma_test->dst_buf, dma_test->dst_dma);

    /* 4. 准备DMA需要的描述符， 告知DMA数据传输的源目的地址、数据量大小等 
        注意：这里使用的API是sg模式的，即scatter-gather模式，可以传输多个不连续的数据块
            但实际上PL段的IP核是配置成了simple模式，即只能传输一个连续的数据块
            所以这里把SG的数量设置成了1，也就是让DMA传输一个连续的数据块
        为什么？
            因为直接使用DAM传输会有问题，原因还不知道，这里可以通过SG模式来传输，有点曲线救国的意思了
            
    */
    sg_init_table(&tx_sg, 1);
	sg_init_table(&rx_sg, 1);
    pr_info("sg_init_table pass\n");

    sg_dma_address(&tx_sg) = dma_test->src_dma;
    sg_dma_address(&rx_sg) = dma_test->dst_dma;
    pr_info("sg_dma_address pass\n");

    sg_dma_len(&tx_sg) = TEST_BUFFER_SIZE;
    sg_dma_len(&rx_sg) = TEST_BUFFER_SIZE;
    pr_info("sg_dma_len pass\n");

    flags = DMA_CTRL_ACK | DMA_PREP_INTERRUPT;
    rxd = dma_test->rx_chan->device->device_prep_slave_sg(dma_test->rx_chan, &rx_sg, 1, DMA_DEV_TO_MEM, flags, NULL);
    pr_info("device_prep_slave_sg rx pass\n");

    txd = dma_test->tx_chan->device->device_prep_slave_sg(dma_test->tx_chan, &tx_sg, 1, DMA_MEM_TO_DEV, flags, NULL);
    pr_info("device_prep_slave_sg tx pass\n");
    if (!rxd || !txd) {
        pr_err("Failed to prepare DMA memcpy\n");
        ret = -ENOMEM;
        goto err_free_buffers;
    }

    init_completion(&dma_test->dma_rx_complete);
    rxd->callback = dma_rx_callback;
    rxd->callback_param = dma_test;
    dma_test->rx_cookie = rxd->tx_submit(rxd);

    init_completion(&dma_test->dma_tx_complete);
    txd->callback = dma_tx_callback;
    txd->callback_param = dma_test;
    dma_test->tx_cookie = txd->tx_submit(txd);

    if (dma_submit_error(dma_test->rx_cookie) ||
        dma_submit_error(dma_test->tx_cookie)) {
        pr_err("Failed to submit DMA transfer\n");
        ret = -ENOMEM;
        goto err_free_buffers;
    }

    /* 5. 启动DMA传输
        这里只是通知了DMA有个传输任务来了，但是实际上并不一定里面就会被执行，只是加入了DMA的任务队列中
        实际传输完成了，会调用dma_rx_callback和dma_tx_callback通知
        当然也可以在这里轮询等待DMA传输完成，但是这样会占用CPU资源，不推荐
    */
    dma_async_issue_pending(dma_test->rx_chan);
    dma_async_issue_pending(dma_test->tx_chan);
    dma_test->start = ktime_get();

    pr_info("DMA transfer start!\n");

    #if 0
    tx_tmo = wait_for_completion_timeout(&dma_test->dma_tx_complete, tx_tmo);

    status = dma_async_is_tx_complete(dma_test->tx_chan, dma_test->tx_cookie,
                        NULL, NULL);

    if (tx_tmo == 0) {
        pr_err("TX test timed out\n");
        ret = -ENOMEM;
        goto err_free_buffers;
    } else if (status != DMA_COMPLETE) {
        pr_err("TX test succ\n");
    }

    rx_tmo = wait_for_completion_timeout(&dma_test->dma_rx_complete, rx_tmo);

    status = dma_async_is_tx_complete(dma_test->rx_chan, dma_test->rx_cookie,
                        NULL, NULL);

    if (rx_tmo == 0) {
        pr_err("RX test timed out\n");
        ret = -ENOMEM;
        goto err_free_buffers;
    } else if (status != DMA_COMPLETE) {
        pr_err("RX test succ\n");
    }

    for(i=0; i<TEST_BUFFER_SIZE; i++)
    {
        //pr_info("%02X ", dma_test->dst_buf[i]);
        if(dma_test->dst_buf[i] != dma_test->src_buf[i])
        {
            pr_err("Data verification failed! dst_buf[%03d]:%d --- src_buf[%03d]:%d\n", 
                dma_test->dst_buf[i], i, dma_test->src_buf[i], i);
            ret = -ENOMEM;
            goto err_free_buffers;
        }
    }
    pr_info("Data verification pass\n");
    pr_info("DMA transfer completed successfully\n");
    #endif

    return 0;

err_free_buffers:
    dma_free_coherent(&pdev->dev, TEST_BUFFER_SIZE, dma_test->src_buf, dma_test->src_dma);
    dma_free_coherent(&pdev->dev, TEST_BUFFER_SIZE, dma_test->dst_buf, dma_test->dst_dma);

err_devfree:
    devm_kfree(&pdev->dev, dma_test);
    return ret;
}

static int axi_dma_test_remove(struct platform_device *pdev)
{
    struct my_dma_test *dma_test = platform_get_drvdata(pdev);

    dma_free_coherent(&pdev->dev, TEST_BUFFER_SIZE, dma_test->src_buf, dma_test->src_dma);
    dma_free_coherent(&pdev->dev, TEST_BUFFER_SIZE, dma_test->dst_buf, dma_test->dst_dma);

    if(dma_test->tx_chan)
        dma_release_channel(dma_test->tx_chan);
    if(dma_test->rx_chan)
        dma_release_channel(dma_test->rx_chan);

    devm_kfree(&pdev->dev, dma_test);

    return 0;
}

static const struct of_device_id axi_dma_test_of_match[] = {
    { .compatible = "xlnx,axi-dma-test-1.00.a", },
    {},
};
MODULE_DEVICE_TABLE(of, axi_dma_test_of_match);

static struct platform_driver axi_dma_test_driver = {
    .driver = {
        .name = "axi_dma_test",
        .of_match_table = axi_dma_test_of_match,
    },
    .probe = axi_dma_test_probe,
    .remove = axi_dma_test_remove,
};

module_platform_driver(axi_dma_test_driver);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Your Name");
MODULE_DESCRIPTION("AXI DMA Test Driver");
